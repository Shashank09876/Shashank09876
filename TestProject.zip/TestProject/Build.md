
Instructions to run:
1. Check out the folder 'TestProject'
2. set localhost as server using node js (http-server) and set File path to browse using http.
    http://127.0.0.1:8080
    if node.js is not installed , then please install it first and install http-server using (npm install http-server -g)
3. Run/open Index.html using http://127.0.0.1:8080 in browser.
4. Make sure all files reside in same folder (which is set to run on server).
5. Once index.html is open , you can select options to navigate to 'View Map' & 'View List' buttons.
6. 'View Map' should show all the coordinates as required and detailed info on marker Selection.
7. 'View List' should show all the JSON data in Table with filter on 'Sector' and 'Fees' Columns.  

