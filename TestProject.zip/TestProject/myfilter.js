
// Get unique values for the Sector and Currency columns

function getColumnsUniqueValue() {
   
    var uni_column_val_dict = {}

    allFilters = document.querySelectorAll(".col-filter")
    allFilters.forEach((filter_i) => {
        col_index = filter_i.parentElement.getAttribute("col-index");
         
        const rows = document.querySelectorAll("#mytable > tbody > tr")
        
        rows.forEach((row) => {
            cell_value = row.querySelector("td:nth-child("+col_index+")").innerHTML;
            //console.log(cell_value)
            // check if the col index is already present in the dict
            if (col_index in uni_column_val_dict) {

                // check if the cell value is already present in the array
                if (uni_column_val_dict[col_index].includes(cell_value)) {
                    // console.log(cell_value + " is already present in the array : " + uni_column_val_dict[col_index])

                } else {
                    //add the value here
                    uni_column_val_dict[col_index].push(cell_value)
                       }

            } else {
                uni_column_val_dict[col_index] = new Array(cell_value)
            }
        });
        
    });
    
    updateColumnfilter(uni_column_val_dict)
};

// update <option> tags to the Sector and Currency columns based on the unique values

function updateColumnfilter(uni_column_val_dict) {
    allFilters = document.querySelectorAll(".col-filter")

    allFilters.forEach((filter_i) => {
        col_index = filter_i.parentElement.getAttribute('col-index')

        uni_column_val_dict[col_index].forEach((i) => {
            filter_i.innerHTML = filter_i.innerHTML + `\n<option value="${i}">${i}</option>`
        });
    });
};

// Create filter_rows() function - should be triggered after each filter selected
function filter_rows() {
    allFilters = document.querySelectorAll(".col-filter")
    var filter_value_dict = {}

    allFilters.forEach((filter_i) => {
        col_index = filter_i.parentElement.getAttribute('col-index')

        value = filter_i.value
        if (value != "all") {
            filter_value_dict[col_index] = value;
        }
    });

    var col_cell_value_dict = {};

    const rows = document.querySelectorAll("#mytable tbody tr");
    rows.forEach((row) => {
        var display_row = true;

        allFilters.forEach((filter_i) => {
            col_index = filter_i.parentElement.getAttribute('col-index')
            col_cell_value_dict[col_index] = row.querySelector("td:nth-child(" + col_index+ ")").innerHTML
        })

        for (var col_i in filter_value_dict) {
            filter_value = filter_value_dict[col_i]
            row_cell_value = col_cell_value_dict[col_i]
            
            if (row_cell_value.indexOf(filter_value) == -1 && filter_value != "all") {
                display_row = false;
                break;
            }
        }

        if (display_row == true) {
            row.style.display = "table-row"
        } else {
            row.style.display = "none"
        }
    })
}
